
#include "xil_printf.h"

void xil_sprintf(char* s, const char *ctrl1, ...);
